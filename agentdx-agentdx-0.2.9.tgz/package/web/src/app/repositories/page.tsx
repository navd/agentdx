import { getDb, fmtTok, fmtNum, timeAgo } from '@/lib/db';
import { RingChart } from '@/components/ring-chart';
import { Collapsible } from '@/components/collapsible';
import { ErrorBoundary } from '@/components/error-boundary';
import { EmptyState } from '@/components/empty-state';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

function getRepositoriesData() {
  const db = getDb();

  // Compute token + session counts live from sessions (the repositories table's
  // precomputed columns lag the canonical io+cache token metric used elsewhere).
  const repos = db.prepare(`
    SELECT r.path, r.origin_url, r.name, r.last_session_at,
      COALESCE(agg.session_count, 0) as session_count,
      COALESCE(agg.total_tokens, 0) as total_tokens
    FROM repositories r
    LEFT JOIN (
      SELECT project_path,
        COUNT(*) as session_count,
        SUM(total_input_tokens + total_output_tokens + total_cache_read) as total_tokens
      FROM sessions WHERE project_path IS NOT NULL
      GROUP BY project_path
    ) agg ON agg.project_path = r.path
    ORDER BY total_tokens DESC
  `).all() as any[];

  const totals = {
    repo_count: repos.length,
    total_sessions: repos.reduce((s, r) => s + (r.session_count || 0), 0),
    total_tokens: repos.reduce((s, r) => s + (r.total_tokens || 0), 0),
  };

  const allSessions = db.prepare(`SELECT COUNT(*) as cnt FROM sessions`).get() as any;
  const activeAgents = db.prepare(`SELECT COUNT(DISTINCT agent) as cnt FROM sessions`).get() as any;

  const agentRows = db.prepare(`
    SELECT DISTINCT project_path, agent FROM sessions WHERE project_path IS NOT NULL
  `).all() as { project_path: string; agent: string }[];

  const agentsByRepo = new Map<string, string[]>();
  for (const row of agentRows) {
    const list = agentsByRepo.get(row.project_path) || [];
    list.push(row.agent);
    agentsByRepo.set(row.project_path, list);
  }

  const langRows = db.prepare(`
    SELECT DISTINCT s.project_path,
      CASE
        WHEN tc.tool_input LIKE '%.tsx%' OR tc.tool_input LIKE '%.ts%' THEN 'TypeScript'
        WHEN tc.tool_input LIKE '%.jsx%' OR tc.tool_input LIKE '%.js%' THEN 'JavaScript'
        WHEN tc.tool_input LIKE '%.py%' THEN 'Python'
        WHEN tc.tool_input LIKE '%.rs%' THEN 'Rust'
        WHEN tc.tool_input LIKE '%.go%' THEN 'Go'
        WHEN tc.tool_input LIKE '%.java%' THEN 'Java'
        WHEN tc.tool_input LIKE '%.rb%' THEN 'Ruby'
        WHEN tc.tool_input LIKE '%.css%' OR tc.tool_input LIKE '%.html%' THEN 'Web'
        ELSE NULL
      END as lang
    FROM sessions s
    JOIN tool_calls tc ON tc.session_id = s.id
    WHERE s.project_path IS NOT NULL AND tc.tool_input IS NOT NULL
  `).all() as { project_path: string; lang: string | null }[];

  const langsByRepo = new Map<string, string[]>();
  for (const row of langRows) {
    if (!row.lang) continue;
    const list = langsByRepo.get(row.project_path) || [];
    if (!list.includes(row.lang)) list.push(row.lang);
    langsByRepo.set(row.project_path, list);
  }

  const langCounts = new Map<string, number>();
  for (const [, langs] of langsByRepo) {
    for (const lang of langs) {
      langCounts.set(lang, (langCounts.get(lang) || 0) + 1);
    }
  }

  return { repos, totals, allSessions, activeAgents, agentsByRepo, langsByRepo, langCounts };
}

const LANG_COLORS: Record<string, string> = {
  TypeScript: '#3178C6', JavaScript: '#F7DF1E', Python: '#3776AB',
  Rust: '#DEA584', Go: '#00ADD8', Java: '#E76F00', Ruby: '#CC342D', Web: '#E34F26',
};

export default function RepositoriesPage() {
  const { repos, totals, allSessions, activeAgents, agentsByRepo, langsByRepo, langCounts } = getRepositoriesData();

  if (repos.length === 0) {
    return (
      <div className="page page-wide">
        <div className="page-head">
          <div>
            <h1 className="page-title">Repositories</h1>
            <p className="page-sub">No repositories tracked</p>
          </div>
        </div>
        <EmptyState
          icon="folder-open"
          title="No repositories found"
          description="No repository data has been collected yet. Run `agentdx collect` to discover repositories from your coding-agent sessions."
          action={{ label: 'Collector status', href: '/collector' }}
        />
      </div>
    );
  }

  const maxTokens = repos[0]?.total_tokens || 1;
  const langEntries = [...langCounts.entries()].sort((a, b) => b[1] - a[1]);
  const langSegments = langEntries.map(([lang, count]) => ({
    key: lang, value: count, color: LANG_COLORS[lang] || 'var(--text-muted)', label: lang,
  }));

  return (
    <div className="page page-wide">
      <div className="page-head">
        <div>
          <h1 className="page-title">Repositories</h1>
          <p className="page-sub">{fmtNum(totals.repo_count || 0)} repositories tracked &middot; {activeAgents.cnt} agents</p>
        </div>
      </div>

      {/* Visual row: Ranked bars + Language ring */}
      <div className="grid mb-20" style={{ gridTemplateColumns: '1fr 260px' }}>
        <ErrorBoundary fallbackTitle="Token usage chart failed to render">
        <div className="card">
          <div className="card-head">
            <div>
              <h3 className="card-title">Token usage by repository</h3>
              <p className="card-sub">ranked by total tokens &middot; click to view sessions</p>
            </div>
          </div>
          <div className="card-pad">
            <div className="col-flex gap-14">
              {repos.filter(r => r.total_tokens > 0).map((r: any) => {
                const pct = (r.total_tokens / maxTokens) * 100;
                const langs = langsByRepo.get(r.path) || [];
                return (
                  <Link key={r.path} href={`/sessions?project=${encodeURIComponent(r.path)}`}>
                    <div className="row between mb-4">
                      <span className="row gap-8">
                        <span className="mono fw6" style={{ fontSize: 13 }}>{r.name}</span>
                        {langs.slice(0, 3).map(lang => (
                          <span key={lang} style={{ display: 'inline-block', padding: '1px 5px', borderRadius: 3, fontSize: 9, fontWeight: 600, background: LANG_COLORS[lang] || 'var(--text-muted)', color: '#fff' }}>{lang}</span>
                        ))}
                      </span>
                      <span className="mono f12 fw6">{fmtTok(r.total_tokens)}</span>
                    </div>
                    <div className="meter">
                      <div className="fill" style={{ width: `${Math.max(pct, 2)}%` }} />
                    </div>
                    <div className="f12 muted" style={{ marginTop: 2 }}>
                      {fmtNum(r.session_count)} session{r.session_count === 1 ? '' : 's'}
                      {r.last_session_at ? ` · ${timeAgo(r.last_session_at)}` : ''}
                    </div>
                  </Link>
                );
              })}
              {repos.filter(r => r.total_tokens > 0).length === 0 && (
                <span className="f13 muted">No token data available</span>
              )}
            </div>
          </div>
        </div>
        </ErrorBoundary>

        <ErrorBoundary fallbackTitle="Languages chart failed to render">
        <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <h3 className="card-title" style={{ marginBottom: 12 }}>Languages</h3>
          {langSegments.length > 0 ? (
            <>
              <RingChart segments={langSegments} size={160} strokeWidth={24} centerValue={String(langEntries.length)} centerLabel="languages" />
              <div className="col-flex gap-6 mt-12" style={{ width: '100%' }}>
                {langEntries.slice(0, 6).map(([lang, count]) => (
                  <div key={lang} className="row between f12">
                    <span className="row gap-6">
                      <span style={{ width: 8, height: 8, borderRadius: 2, background: LANG_COLORS[lang] || 'var(--text-muted)', display: 'inline-block' }} />
                      {lang}
                    </span>
                    <span className="mono muted">{count}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <span className="f13 muted">No language data</span>
          )}
        </div>
        </ErrorBoundary>
      </div>

      {/* KPI strip */}
      <div className="grid g-4 mb-20">
        <div className="card stat" style={{ padding: '15px 16px' }}>
          <div className="stat-label">Repositories</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{fmtNum(totals.repo_count || 0)}</div>
        </div>
        <div className="card stat" style={{ padding: '15px 16px' }}>
          <div className="stat-label">Sessions</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{fmtNum(totals.total_sessions || 0)}</div>
          <div className="stat-foot">of {fmtNum(allSessions.cnt || 0)} total · mapped to a repo</div>
        </div>
        <div className="card stat" style={{ padding: '15px 16px' }}>
          <div className="stat-label">Total tokens</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{fmtTok(totals.total_tokens || 0)}</div>
        </div>
        <div className="card stat" style={{ padding: '15px 16px' }}>
          <div className="stat-label">Active agents</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{fmtNum(activeAgents.cnt || 0)}</div>
        </div>
      </div>

      {/* Repositories table (collapsible) */}
      <div className="card">
        <Collapsible title="Repository details" count={repos.length}>
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Repository</th>
                  <th>Provider</th>
                  <th>Languages</th>
                  <th className="num">Sessions</th>
                  <th className="num">Tokens</th>
                  <th>Agents</th>
                  <th>Last activity</th>
                </tr>
              </thead>
              <tbody>
                {repos.map((r: any) => {
                  const agents = agentsByRepo.get(r.path) || [];
                  const langs = langsByRepo.get(r.path) || [];
                  return (
                    <tr key={r.path} className="clickable">
                      <td>
                        <Link href={`/sessions?project=${encodeURIComponent(r.path)}`}>
                          <span className="mono fw6" style={{ color: 'var(--text)' }}>{r.name}</span>
                          <br /><span className="f12 muted">{r.path}</span>
                        </Link>
                      </td>
                      <td><span className="badge badge-info"><span className="dot" style={{ background: 'var(--info)' }} />Local</span></td>
                      <td>
                        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                          {langs.length > 0 ? langs.map(lang => (
                            <span key={lang} style={{ display: 'inline-block', padding: '2px 7px', borderRadius: 3, fontSize: 10, fontWeight: 600, background: LANG_COLORS[lang] || 'var(--text-muted)', color: '#fff' }}>{lang}</span>
                          )) : <span className="subtle">--</span>}
                        </div>
                      </td>
                      <td className="num">{fmtNum(r.session_count)}</td>
                      <td className="num">{fmtTok(r.total_tokens || 0)}</td>
                      <td>
                        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                          {agents.length > 0 ? agents.map(a => <span key={a} className="tag-mono">{a}</span>) : <span className="subtle">--</span>}
                        </div>
                      </td>
                      <td><span className="f12 muted">{r.last_session_at ? timeAgo(r.last_session_at) : '--'}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Collapsible>
      </div>
    </div>
  );
}
