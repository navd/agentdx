import { getDb, fmtNum, fmtTok, timeAgo, getErrorSignalAgents } from '@/lib/db';
import Link from 'next/link';
import { EventLogFilter } from '@/components/event-log-filter';
import { Collapsible } from '@/components/collapsible';
import { DrilldownTiles } from '@/components/drilldown-tiles';
import { ErrorBoundary } from '@/components/error-boundary';
import { EmptyState } from '@/components/empty-state';
import { ShieldCheck, ShieldAlert, Terminal as TerminalIcon, FileX, AlertTriangle, Wrench } from 'lucide-react';

export const dynamic = 'force-dynamic';

function getRulesData() {
  const db = getDb();

  // KPI totals
  const kpi = db.prepare(`
    SELECT
      COUNT(*) as total_calls,
      SUM(CASE WHEN is_error = 1 THEN 1 ELSE 0 END) as error_count,
      COUNT(DISTINCT tool_name) as distinct_tools
    FROM tool_calls
  `).get() as any;

  // Error-prone tools
  const errorTools = db.prepare(`
    SELECT
      tool_name,
      COUNT(*) as cnt,
      SUM(CASE WHEN is_error = 1 THEN 1 ELSE 0 END) as errors
    FROM tool_calls
    GROUP BY tool_name
    HAVING errors > 0
    ORDER BY errors DESC
    LIMIT 15
  `).all() as any[];

  // Recent errors
  const recentErrors = db.prepare(`
    SELECT tc.*, s.agent, s.project_path
    FROM tool_calls tc
    JOIN sessions s ON s.id = tc.session_id
    WHERE tc.is_error = 1
    ORDER BY tc.timestamp DESC
    LIMIT 20
  `).all() as any[];

  const blockedCommands = db.prepare(`
    SELECT COUNT(*) as c FROM tool_calls WHERE is_error = 1 AND tool_name IN ('Bash', 'exec_command')
  `).get() as any;

  const blockedWrites = db.prepare(`
    SELECT COUNT(*) as c FROM tool_calls WHERE is_error = 1 AND tool_name IN ('Write', 'Edit', 'write_file', 'apply_patch')
  `).get() as any;

  const sessionsWithErrors = db.prepare(`
    SELECT COUNT(DISTINCT session_id) as c FROM tool_calls WHERE is_error = 1
  `).get() as any;

  const policyLog = db.prepare(`
    SELECT tc.tool_name, tc.is_error, tc.timestamp, tc.session_id,
      s.agent, s.project_path
    FROM tool_calls tc
    JOIN sessions s ON s.id = tc.session_id
    ORDER BY tc.timestamp DESC
    LIMIT 30
  `).all() as any[];

  const signal = getErrorSignalAgents(db);
  const blindAgents = (db.prepare('SELECT DISTINCT agent FROM sessions').all() as any[]).map((r) => r.agent).filter((a) => !signal.has(a));

  return { kpi, errorTools, recentErrors, blockedCommands: blockedCommands.c, blockedWrites: blockedWrites.c, sessionsWithErrors: sessionsWithErrors.c, policyLog, blindAgents };
}

export default function RulesPage() {
  const { kpi, errorTools, recentErrors, blockedCommands, blockedWrites, sessionsWithErrors, policyLog, blindAgents } = getRulesData();

  const totalCalls = kpi.total_calls || 0;
  const errorCount = kpi.error_count || 0;
  const errorRate = totalCalls > 0 ? ((errorCount / totalCalls) * 100).toFixed(1) : '0.0';
  const distinctTools = kpi.distinct_tools || 0;

  const maxErrors = errorTools[0]?.errors || 1;

  if (totalCalls === 0) {
    return (
      <div className="page page-wide">
        <div className="page-head">
          <div>
            <h1 className="page-title">Rules &amp; Policy</h1>
            <p className="page-sub">No tool call data</p>
          </div>
        </div>
        <EmptyState
          icon="shield-check"
          title="No policy data yet"
          description="Tool call policy and error analysis requires collected session data. Run `agentdx collect` to get started."
          action={{ label: 'View sessions', href: '/sessions' }}
        />
      </div>
    );
  }

  return (
    <div className="page page-wide">
      <div className="page-head">
        <div>
          <h1 className="page-title">Rules &amp; Policy</h1>
          <p className="page-sub">Tool-call outcomes and error analysis &middot; observed, not enforced</p>
        </div>
      </div>

      {blindAgents.length > 0 && (
        <div className="card card-pad mb-20" style={{ background: 'var(--surface-2)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <span style={{ fontSize: 15 }}>ⓘ</span>
          <div className="f12" style={{ color: 'var(--text-muted)', lineHeight: 1.55 }}>
            Error counts cover only agents that record per-tool errors. <strong>{blindAgents.join(', ')}</strong> {blindAgents.length === 1 ? "doesn't" : "don't"} emit a tool-error signal, so {blindAgents.length === 1 ? "its calls are" : "their calls are"} all counted as successful here.
          </div>
        </div>
      )}

      {/* Drilldown tiles */}
      <div className="mb-20">
        <DrilldownTiles tiles={[
          { label: 'Total calls', value: fmtNum(totalCalls), detail: `${distinctTools} distinct tools`, href: '/agents', icon: <Wrench size={18} />, tone: 'accent' },
          { label: 'Succeeded', value: fmtNum(totalCalls - errorCount), detail: 'no error returned', href: '/agents', icon: <ShieldCheck size={18} />, tone: 'pos' },
          { label: 'Errors', value: fmtNum(errorCount), detail: `${errorRate}% error rate`, href: '/risk', icon: <ShieldAlert size={18} />, tone: errorCount > 0 ? 'neg' : 'pos' },
          { label: 'Shell errors', value: fmtNum(blockedCommands), detail: 'failed commands', href: '/risk', icon: <TerminalIcon size={18} />, tone: blockedCommands > 0 ? 'warn' : 'pos' },
          { label: 'Write errors', value: fmtNum(blockedWrites), detail: 'file write failures', href: '/risk', icon: <FileX size={18} />, tone: blockedWrites > 0 ? 'warn' : 'pos' },
          { label: 'Sessions affected', value: fmtNum(sessionsWithErrors), detail: 'with tool errors', href: '/sessions', icon: <AlertTriangle size={18} />, tone: sessionsWithErrors > 0 ? 'warn' : 'pos' },
        ]} />
      </div>

      {/* Error breakdown */}
      <ErrorBoundary fallbackTitle="Error breakdown section failed to render">
      {errorCount > 0 && (
        <div className="card mb-20" style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}>
          <div className="card-pad">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--warn)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" width="22" height="22">
                  <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/>
                  <path d="M12 9v4M12 17h.01"/>
                </svg>
              </div>
              <div>
                <div className="fw6" style={{ fontSize: 15 }}>Error breakdown</div>
                <div className="f12 muted">{errorCount} tool-call errors recorded across {sessionsWithErrors} sessions — observed from history, not blocked by a policy engine</div>
              </div>
            </div>
            <div className="grid g-4" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
              <div className="card stat" style={{ padding: '10px 12px', background: 'var(--surface)' }}>
                <div className="stat-label" style={{ fontSize: 11 }}>Shell errors</div>
                <div className="stat-value mono" style={{ fontSize: 18 }}>{blockedCommands}</div>
              </div>
              <div className="card stat" style={{ padding: '10px 12px', background: 'var(--surface)' }}>
                <div className="stat-label" style={{ fontSize: 11 }}>Write errors</div>
                <div className="stat-value mono" style={{ fontSize: 18 }}>{blockedWrites}</div>
              </div>
              <div className="card stat" style={{ padding: '10px 12px', background: 'var(--surface)' }}>
                <div className="stat-label" style={{ fontSize: 11 }}>Other errors</div>
                <div className="stat-value mono" style={{ fontSize: 18 }}>{errorCount - blockedCommands - blockedWrites}</div>
              </div>
              <div className="card stat" style={{ padding: '10px 12px', background: 'var(--surface)' }}>
                <div className="stat-label" style={{ fontSize: 11 }}>Sessions affected</div>
                <div className="stat-value mono" style={{ fontSize: 18 }}>{sessionsWithErrors}</div>
              </div>
            </div>
          </div>
        </div>
      )}
      </ErrorBoundary>

      {/* Error-prone tools as visual bars */}
      <ErrorBoundary fallbackTitle="Error-prone tools chart failed to render">
      <div className="card mb-20">
        <div className="card-head">
          <div>
            <h3 className="card-title">Error-prone tools</h3>
            <p className="card-sub">ranked by error count</p>
          </div>
        </div>
        <div className="card-pad">
          {errorTools.length > 0 ? (
            <div className="col-flex gap-14">
              {errorTools.map((t: any) => {
                const rate = t.cnt > 0 ? ((t.errors / t.cnt) * 100).toFixed(1) : '0.0';
                return (
                  <div key={t.tool_name}>
                    <div className="row between mb-4">
                      <span className="row gap-8">
                        <span className="tag-mono">{t.tool_name}</span>
                        <span className="mono f12" style={{ color: 'var(--neg)' }}>{rate}%</span>
                      </span>
                      <span className="mono f12 fw6">{fmtNum(t.errors)} / {fmtNum(t.cnt)}</span>
                    </div>
                    <div className="meter">
                      <div className="fill" style={{ width: `${(t.errors / maxErrors) * 100}%`, background: 'var(--neg)' }} />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <span className="f13 muted">No tool errors recorded</span>
          )}
        </div>
      </div>
      </ErrorBoundary>

      {/* Recent errors (collapsible) */}
      <ErrorBoundary fallbackTitle="Recent errors table failed to render">
      <div className="card">
        <Collapsible title="Recent errors" count={recentErrors.length}>
          <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>Tool</th>
                <th>Agent</th>
                <th>Project</th>
                <th>Error preview</th>
                <th>When</th>
                <th>Session</th>
              </tr>
            </thead>
            <tbody>
              {recentErrors.map((e: any, i: number) => {
                const preview = e.tool_output
                  ? String(e.tool_output).slice(0, 100) + (String(e.tool_output).length > 100 ? '...' : '')
                  : '';
                const projectName = e.project_path
                  ? e.project_path.split('/').pop()
                  : '';
                return (
                  <tr key={`${e.id}-${i}`}>
                    <td><span className="tag-mono">{e.tool_name}</span></td>
                    <td><span className="tag-mono">{e.agent}</span></td>
                    <td><span className="f12 muted">{projectName}</span></td>
                    <td>
                      <span className="f12 muted" style={{ wordBreak: 'break-all' }}>
                        {preview || <span className="subtle">&mdash;</span>}
                      </span>
                    </td>
                    <td><span className="f12 muted">{timeAgo(e.timestamp)}</span></td>
                    <td>
                      <Link href={`/sessions/${e.session_id}`}>
                        <span className="f12 mono" style={{ color: 'var(--accent)' }}>
                          {String(e.session_id).slice(0, 8)}
                        </span>
                      </Link>
                    </td>
                  </tr>
                );
              })}
              {recentErrors.length === 0 && (
                <tr>
                  <td colSpan={6} className="muted" style={{ textAlign: 'center', padding: 24 }}>
                    No recent errors
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        </Collapsible>
      </div>
      </ErrorBoundary>
      {/* Policy event log */}
      <ErrorBoundary fallbackTitle="Policy event log failed to render">
      <EventLogFilter events={policyLog.map((e: any) => ({
        tool_name: e.tool_name,
        is_error: e.is_error,
        session_id: e.session_id,
        agent: e.agent,
        project_path: e.project_path,
        when: timeAgo(e.timestamp),
      }))} />
      </ErrorBoundary>
    </div>
  );
}
