import { getDb, fmtNum, timeAgo } from '@/lib/db';
import Link from 'next/link';
import { Collapsible } from '@/components/collapsible';
import { DrilldownTiles } from '@/components/drilldown-tiles';
import { ErrorBoundary } from '@/components/error-boundary';
import { EmptyState } from '@/components/empty-state';
import { GitPullRequest, GitBranch, FolderGit2, Upload } from 'lucide-react';

export const dynamic = 'force-dynamic';

function getPRData() {
  const db = getDb();

  // One row per session, with aggregated evidence flags. (The old query kept a
  // row per matching tool call via a per-row CASE, so a session that both
  // committed and pushed was counted twice.)
  const prSessions = db.prepare(`
    SELECT
      s.id, s.title, s.agent, s.git_branch, s.project_path, s.started_at,
      s.first_user_message,
      MAX(CASE WHEN tc.tool_input LIKE '%gh pr create%' THEN 1 ELSE 0 END) as has_pr,
      MAX(CASE WHEN tc.tool_input LIKE '%git push%' THEN 1 ELSE 0 END) as has_push,
      MAX(CASE WHEN tc.tool_input LIKE '%git commit%' THEN 1 ELSE 0 END) as has_commit
    FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash'
      AND (tc.tool_input LIKE '%git push%' OR tc.tool_input LIKE '%git commit%' OR tc.tool_input LIKE '%gh pr create%')
      AND s.model_primary != '<synthetic>'
    GROUP BY s.id
    ORDER BY s.started_at DESC
  `).all().map((s: any) => ({
    ...s,
    evidence: s.has_pr ? 'gh pr create' : s.has_push ? 'git push' : s.has_commit ? 'git commit' : 'git activity',
  })) as any[];

  const prCreated = (db.prepare(`
    SELECT COUNT(DISTINCT s.id) as cnt FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash' AND tc.tool_input LIKE '%gh pr create%' AND s.model_primary != '<synthetic>'
  `).get() as any).cnt;

  const pushSessions = (db.prepare(`
    SELECT COUNT(DISTINCT s.id) as cnt FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash' AND tc.tool_input LIKE '%git push%' AND s.model_primary != '<synthetic>'
  `).get() as any).cnt;

  const commitSessions = (db.prepare(`
    SELECT COUNT(DISTINCT s.id) as cnt FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash' AND tc.tool_input LIKE '%git commit%' AND s.model_primary != '<synthetic>'
  `).get() as any).cnt;

  const uniqueBranches = (db.prepare(`
    SELECT COUNT(DISTINCT s.git_branch) as cnt FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash' AND (tc.tool_input LIKE '%git push%' OR tc.tool_input LIKE '%gh pr%')
      AND s.git_branch IS NOT NULL AND s.model_primary != '<synthetic>'
  `).get() as any).cnt;

  const uniqueRepos = (db.prepare(`
    SELECT COUNT(DISTINCT s.project_path) as cnt FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash' AND (tc.tool_input LIKE '%git push%' OR tc.tool_input LIKE '%gh pr%')
      AND s.project_path IS NOT NULL AND s.model_primary != '<synthetic>'
  `).get() as any).cnt;

  // Evidence breakdown for visual
  const evidenceCounts = { 'gh pr create': 0, 'gh pr': 0, 'git push': 0, 'git commit': 0 };
  for (const s of prSessions) {
    if (s.evidence in evidenceCounts) evidenceCounts[s.evidence as keyof typeof evidenceCounts]++;
  }

  // Per-agent shipping: how many of each agent's sessions reached commit / push
  // / PR-create. "Ship rate" = share of an agent's sessions that produced a
  // commit — the honest "which tool actually lands code" signal. These are
  // detected from shell commands (intent), not guaranteed merge outcomes.
  const totalsByAgent = new Map<string, number>();
  for (const r of db.prepare('SELECT agent, COUNT(*) as cnt FROM sessions GROUP BY agent').all() as any[]) {
    totalsByAgent.set(r.agent, r.cnt);
  }
  const shipRows = db.prepare(`
    SELECT s.agent AS agent,
      COUNT(DISTINCT CASE WHEN tc.tool_input LIKE '%git commit%' THEN s.id END) AS commits,
      COUNT(DISTINCT CASE WHEN tc.tool_input LIKE '%git push%' THEN s.id END) AS pushes,
      COUNT(DISTINCT CASE WHEN tc.tool_input LIKE '%gh pr create%' THEN s.id END) AS prs
    FROM sessions s
    INNER JOIN tool_calls tc ON tc.session_id = s.id
    WHERE tc.tool_name = 'Bash' AND s.model_primary != '<synthetic>'
      AND (tc.tool_input LIKE '%git commit%' OR tc.tool_input LIKE '%git push%' OR tc.tool_input LIKE '%gh pr create%')
    GROUP BY s.agent
  `).all() as any[];
  const shipByAgent = shipRows.map((r) => {
    const total = totalsByAgent.get(r.agent) || 0;
    return {
      agent: r.agent,
      sessions: total,
      commits: r.commits || 0,
      pushes: r.pushes || 0,
      prs: r.prs || 0,
      shipRate: total > 0 ? (r.commits / total) * 100 : 0,
    };
  }).sort((a, z) => z.commits - a.commits);

  return { prSessions, totalPRs: prCreated || 0, pushSessionCount: pushSessions || 0, commitSessionCount: commitSessions || 0, branchCount: uniqueBranches || 0, repoCount: uniqueRepos || 0, evidenceCounts, shipByAgent };
}

function repoName(path: string | null): string {
  if (!path) return '—';
  return path.split('/').pop() || path;
}

export default function PullRequestsPage() {
  const { prSessions, totalPRs, pushSessionCount, commitSessionCount, branchCount, repoCount, evidenceCounts, shipByAgent } = getPRData();

  if (prSessions.length === 0 && totalPRs === 0) {
    return (
      <div className="page page-wide">
        <div className="page-head">
          <div>
            <h1 className="page-title">Git Activity</h1>
            <p className="page-sub">No git activity detected</p>
          </div>
        </div>
        <EmptyState
          icon="file-diff"
          title="No git activity"
          description="Sessions with git push, git commit, or gh pr create activity will appear here once collected."
          action={{ label: 'View sessions', href: '/sessions' }}
        />
      </div>
    );
  }

  const maxEvidence = Math.max(...Object.values(evidenceCounts), 1);

  return (
    <div className="page page-wide">
      <div className="page-head">
        <div>
          <h1 className="page-title">Git Activity</h1>
          <p className="page-sub">Commits, pushes &amp; PR activity derived from coding-agent sessions</p>
        </div>
      </div>

      {/* Drilldown tiles — lead with commits (the activity that actually exists) */}
      <div className="mb-20">
        <DrilldownTiles tiles={[
          { label: 'Commit sessions', value: fmtNum(commitSessionCount), detail: 'git commit activity', href: '/sessions', icon: <GitBranch size={18} />, tone: 'accent' },
          { label: 'Push sessions', value: fmtNum(pushSessionCount), detail: 'git push activity', href: '/sessions', icon: <Upload size={18} />, tone: 'info' },
          { label: 'PRs detected', value: fmtNum(totalPRs), detail: 'via gh pr create', href: '/sessions', icon: <GitPullRequest size={18} />, tone: totalPRs > 0 ? 'pos' : 'neutral' },
          { label: 'Branches', value: fmtNum(branchCount), detail: 'unique branches', href: '/sessions', icon: <GitBranch size={18} />, tone: 'pos' },
          { label: 'Repositories', value: fmtNum(repoCount), detail: 'linked repos', href: '/repositories', icon: <FolderGit2 size={18} />, tone: 'warn' },
        ]} />
      </div>

      {/* Which agent ships — per-agent commit/push/PR activity + ship rate */}
      {shipByAgent.length > 0 && (
        <ErrorBoundary fallbackTitle="Per-agent shipping failed to render">
        <div className="card mb-20">
          <div className="card-head">
            <div>
              <h3 className="card-title">Which agent ships</h3>
              <p className="card-sub">how often each agent&apos;s sessions reach a commit, push, or PR</p>
            </div>
          </div>
          <div className="card-pad">
            <div className="col-flex gap-16">
              {shipByAgent.map((a) => {
                const maxCommits = Math.max(...shipByAgent.map((x) => x.commits), 1);
                return (
                  <div key={a.agent}>
                    <div className="row between mb-4">
                      <span className="row gap-8">
                        <Link href={`/sessions?agent=${encodeURIComponent(a.agent)}`} className="mono fw6" style={{ fontSize: 13, color: 'var(--text)' }}>{a.agent}</Link>
                        <span className="f12 muted">{a.commits} commit{a.commits === 1 ? '' : 's'} · {a.pushes} push{a.pushes === 1 ? '' : 'es'}{a.prs > 0 ? ` · ${a.prs} PR` : ''}</span>
                      </span>
                      <span className="mono f12 fw6">{a.shipRate.toFixed(0)}% ship rate</span>
                    </div>
                    <div className="meter">
                      <div className="fill" style={{ width: `${Math.max(2, (a.commits / maxCommits) * 100)}%` }} />
                    </div>
                    <div className="f12 muted" style={{ marginTop: 2 }}>
                      {a.commits} of {a.sessions} session{a.sessions === 1 ? '' : 's'} produced a commit
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="f12" style={{ color: 'var(--text-muted)', lineHeight: 1.55, marginTop: 14 }}>
              Detected from shell commands the agent ran — intent, not a guaranteed merge. &ldquo;Ship rate&rdquo; is the share of that agent&apos;s sessions that produced a <span className="mono">git commit</span>.
            </div>
          </div>
        </div>
        </ErrorBoundary>
      )}

      {/* Evidence breakdown */}
      <ErrorBoundary fallbackTitle="Evidence breakdown failed to render">
      <div className="card mb-20">
        <div className="card-head">
          <div>
            <h3 className="card-title">Evidence breakdown</h3>
            <p className="card-sub">git activity types detected across sessions</p>
          </div>
        </div>
        <div className="card-pad">
          <div className="col-flex gap-14">
            {Object.entries(evidenceCounts).filter(([, v]) => v > 0).map(([key, count]) => (
              <div key={key}>
                <div className="row between mb-4">
                  <span className="tag-mono">{key}</span>
                  <span className="mono f12 fw6">{count}</span>
                </div>
                <div className="meter">
                  <div className="fill" style={{ width: `${(count / maxEvidence) * 100}%`, background: key.includes('pr') ? 'var(--accent)' : 'var(--info)' }} />
                </div>
              </div>
            ))}
            {Object.values(evidenceCounts).every(v => v === 0) && (
              <span className="f13 muted">No git activity detected yet</span>
            )}
          </div>
        </div>
      </div>
      </ErrorBoundary>

      {/* PR sessions table (collapsible) */}
      <ErrorBoundary fallbackTitle="PR sessions table failed to render">
      <div className="card mb-20">
        {prSessions.length > 0 ? (
          <Collapsible title="Sessions with git activity" count={prSessions.length} defaultOpen>
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Session</th>
                    <th>Agent</th>
                    <th>Branch</th>
                    <th>Repository</th>
                    <th>Evidence</th>
                    <th>When</th>
                  </tr>
                </thead>
                <tbody>
                  {prSessions.map((s: any, i: number) => (
                    <tr key={`${s.id}-${s.evidence}-${i}`} className="clickable">
                      <td>
                        <Link href={`/sessions/${s.id}`}>
                          <span className="hash fw6" style={{ color: 'var(--text)' }}>{s.id.slice(0, 8)}</span>
                          <br /><span className="f12 subtle">{s.title || s.first_user_message?.slice(0, 40) || '—'}</span>
                        </Link>
                      </td>
                      <td><span className="tag-mono">{s.agent}</span></td>
                      <td><span className="mono f12">{s.git_branch || '—'}</span></td>
                      <td><span className="mono f12">{repoName(s.project_path)}</span></td>
                      <td>
                        <span className={`badge ${s.evidence === 'gh pr create' ? 'badge-pos' : 'badge-info'}`}>
                          {s.evidence}
                        </span>
                      </td>
                      <td className="muted f12">{timeAgo(s.started_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Collapsible>
        ) : (
          <div className="card-pad" style={{ textAlign: 'center', padding: 40 }}>
            <GitPullRequest size={32} style={{ color: 'var(--text-subtle)', marginBottom: 12 }} />
            <h3 className="fw6" style={{ marginBottom: 8 }}>No PR activity detected yet</h3>
            <p className="muted f13">Sessions with <code className="mono">git push</code>, <code className="mono">git commit</code>, or <code className="mono">gh pr create</code> will appear here.</p>
          </div>
        )}
      </div>
      </ErrorBoundary>
    </div>
  );
}
