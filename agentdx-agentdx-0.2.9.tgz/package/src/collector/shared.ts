import { basename } from 'path';
import type Database from 'better-sqlite3';
import type { Session, Message, ToolCall, ModelUsage } from '../core/types.js';

export interface CollectorStats {
  sessions: number;
  messages: number;
  toolCalls: number;
  errors: string[];
}

export function emptyStats(): CollectorStats {
  return { sessions: 0, messages: 0, toolCalls: 0, errors: [] };
}

export function truncate(s: string | null | undefined, max = 10000): string | null {
  if (!s) return null;
  return s.length > max ? s.slice(0, max) + '…' : s;
}

/** Minimum valid timestamp: 2023-01-01T00:00:00Z */
const MIN_TIMESTAMP = 1672531200000;

/**
 * Validates a session's started_at timestamp.
 * Rejects timestamps before 2023-01-01 or more than 1 day in the future.
 * Returns true if the timestamp is valid, false otherwise.
 */
export function isValidSessionTimestamp(startedAt: number): boolean {
  if (startedAt < MIN_TIMESTAMP) return false;
  if (startedAt > Date.now() + 86400000) return false;
  return true;
}

/**
 * Returns true if the error code indicates a permission denied error (EACCES or EPERM).
 */
export function isPermissionError(err: any): boolean {
  return err?.code === 'EACCES' || err?.code === 'EPERM';
}

export interface DbWriter {
  insertSession: Database.Statement;
  insertMessage: Database.Statement;
  insertToolCall: Database.Statement;
  insertModelUsage: Database.Statement;
  insertRepo: Database.Statement;
  updateRepo: Database.Statement;
  insertSkill: Database.Statement;
  getWatermark: Database.Statement;
  setWatermark: Database.Statement;
  db: Database.Database;
}

export interface SkillInvocation {
  id: string;
  session_id: string;
  message_id: string | null;
  skill: string;
  source: 'slash' | 'command' | 'tool';
  timestamp: number;
}

// `<command-name>/foo</command-name>` (the leading slash is optional).
const CMD_TAG_RE = /<command-name>\s*\/?([A-Za-z][\w:-]*)\s*<\/command-name>/g;
// A user message that *is* a slash command: `/foo ...`. Rejects file paths by
// disallowing a second slash in the first token (e.g. `/Users/...`).
const SLASH_RE = /^\/([A-Za-z][\w-]*)(?:\s|$)/;

/** Pull the skill name out of a `Skill` tool call's JSON input, if present. */
function skillFromToolInput(input: string | null): string | null {
  if (!input) return null;
  try {
    const j = JSON.parse(input);
    return j && typeof j.skill === 'string' && j.skill ? j.skill : null;
  } catch {
    return null;
  }
}

/**
 * Detect skill / slash-command invocations within a parsed session from three
 * sources: the `Skill` tool, `<command-name>` tags, and a leading `/cmd` in a
 * user message. One row per invocation.
 */
export function extractSkills(parsed: ParsedSession): SkillInvocation[] {
  const out: SkillInvocation[] = [];
  const sid = parsed.session.id;
  let n = 0;

  for (const tc of parsed.toolCalls) {
    if (tc.tool_name !== 'Skill') continue;
    const skill = skillFromToolInput(tc.tool_input);
    if (skill) out.push({ id: `${sid}-sk-${n++}`, session_id: sid, message_id: tc.message_id ?? null, skill, source: 'tool', timestamp: tc.timestamp });
  }

  for (const m of parsed.messages) {
    if (m.role !== 'user' || !m.content_text) continue;
    let matched = false;
    CMD_TAG_RE.lastIndex = 0;
    let cm: RegExpExecArray | null;
    while ((cm = CMD_TAG_RE.exec(m.content_text))) {
      out.push({ id: `${sid}-sk-${n++}`, session_id: sid, message_id: m.id, skill: cm[1], source: 'command', timestamp: m.timestamp });
      matched = true;
    }
    if (matched) continue;
    const sm = SLASH_RE.exec(m.content_text.trim());
    if (sm) out.push({ id: `${sid}-sk-${n++}`, session_id: sid, message_id: m.id, skill: sm[1], source: 'slash', timestamp: m.timestamp });
  }

  return out;
}

/**
 * Backfill skill_invocations from already-stored messages + tool calls. Runs
 * once (no-op if the table already has rows). Lets existing databases gain
 * skill data without a full re-collect (collection uses ON CONFLICT DO NOTHING
 * so it never re-processes existing sessions).
 */
export function backfillSkills(db: Database.Database): number {
  const exists = db.prepare(`SELECT 1 FROM skill_invocations LIMIT 1`).get();
  if (exists) return 0;

  const insert = db.prepare(`
    INSERT OR IGNORE INTO skill_invocations (id, session_id, message_id, skill, source, timestamp)
    VALUES (@id, @session_id, @message_id, @skill, @source, @timestamp)
  `);
  let inserted = 0;
  const run = db.transaction(() => {
    const tools = db.prepare(`SELECT id, session_id, message_id, tool_input, timestamp FROM tool_calls WHERE tool_name = 'Skill'`).all() as any[];
    for (const tc of tools) {
      const skill = skillFromToolInput(tc.tool_input);
      if (!skill) continue;
      insert.run({ id: `${tc.id}-sk`, session_id: tc.session_id, message_id: tc.message_id ?? null, skill, source: 'tool', timestamp: tc.timestamp });
      inserted++;
    }
    const msgs = db.prepare(`SELECT id, session_id, content_text, timestamp FROM messages WHERE role = 'user' AND (content_text LIKE '/%' OR content_text LIKE '%command-name%')`).all() as any[];
    for (const m of msgs) {
      const text: string = m.content_text || '';
      let matched = false;
      CMD_TAG_RE.lastIndex = 0;
      let cm: RegExpExecArray | null;
      let k = 0;
      while ((cm = CMD_TAG_RE.exec(text))) {
        insert.run({ id: `${m.id}-sk-${k++}`, session_id: m.session_id, message_id: m.id, skill: cm[1], source: 'command', timestamp: m.timestamp });
        inserted++; matched = true;
      }
      if (matched) continue;
      const sm = SLASH_RE.exec(text.trim());
      if (sm) { insert.run({ id: `${m.id}-sk-0`, session_id: m.session_id, message_id: m.id, skill: sm[1], source: 'slash', timestamp: m.timestamp }); inserted++; }
    }
  });
  run();
  return inserted;
}

export function createDbWriter(db: Database.Database): DbWriter {
  return {
    insertSession: db.prepare(`
      INSERT INTO sessions (id, agent, agent_version, title, status, project_path,
        repository_url, git_branch, git_sha, model_primary, started_at, ended_at, duration_ms,
        total_input_tokens, total_output_tokens, total_cache_read, total_cache_write,
        turn_count, tool_call_count, first_user_message, source_path, collected_at)
      VALUES (@id, @agent, @agent_version, @title, @status, @project_path,
        @repository_url, @git_branch, @git_sha, @model_primary, @started_at, @ended_at, @duration_ms,
        @total_input_tokens, @total_output_tokens, @total_cache_read, @total_cache_write,
        @turn_count, @tool_call_count, @first_user_message, @source_path, @collected_at)
      ON CONFLICT(id) DO NOTHING
    `),
    insertMessage: db.prepare(`
      INSERT INTO messages (id, session_id, parent_id, role, model, content_text,
        content_type, timestamp, input_tokens, output_tokens, cache_read, cache_write, seq)
      VALUES (@id, @session_id, @parent_id, @role, @model, @content_text,
        @content_type, @timestamp, @input_tokens, @output_tokens, @cache_read, @cache_write, @seq)
      ON CONFLICT(id) DO NOTHING
    `),
    insertToolCall: db.prepare(`
      INSERT INTO tool_calls (id, session_id, message_id, tool_name, tool_input,
        tool_output, is_error, duration_ms, timestamp)
      VALUES (@id, @session_id, @message_id, @tool_name, @tool_input,
        @tool_output, @is_error, @duration_ms, @timestamp)
      ON CONFLICT(id) DO NOTHING
    `),
    insertModelUsage: db.prepare(`
      INSERT OR REPLACE INTO model_usage (session_id, model, input_tokens, output_tokens,
        cache_read, cache_write, message_count)
      VALUES (@session_id, @model, @input_tokens, @output_tokens,
        @cache_read, @cache_write, @message_count)
    `),
    insertRepo: db.prepare(`
      INSERT OR IGNORE INTO repositories (path, name, session_count, total_tokens)
      VALUES (@path, @name, 0, 0)
    `),
    updateRepo: db.prepare(`
      UPDATE repositories SET
        session_count = session_count + 1,
        last_session_at = MAX(COALESCE(last_session_at, 0), @last_session_at),
        total_tokens = total_tokens + @total_tokens
      WHERE path = @path
    `),
    insertSkill: db.prepare(`
      INSERT OR IGNORE INTO skill_invocations (id, session_id, message_id, skill, source, timestamp)
      VALUES (@id, @session_id, @message_id, @skill, @source, @timestamp)
    `),
    getWatermark: db.prepare(`SELECT * FROM collection_state WHERE source = ?`),
    setWatermark: db.prepare(`
      INSERT OR REPLACE INTO collection_state (source, last_file, last_offset, last_session_id, last_timestamp, updated_at)
      VALUES (@source, @last_file, @last_offset, @last_session_id, @last_timestamp, @updated_at)
    `),
    db,
  };
}

export interface ParsedSession {
  session: Session;
  messages: Message[];
  toolCalls: ToolCall[];
  modelUsage: Map<string, ModelUsage>;
}

export function persistSession(w: DbWriter, parsed: ParsedSession, stats: CollectorStats): void {
  // Validate session timestamp before inserting
  if (!isValidSessionTimestamp(parsed.session.started_at)) {
    console.warn(`[collector] Skipping session ${parsed.session.id}: invalid started_at ${parsed.session.started_at} (before 2023-01-01 or more than 1 day in the future)`);
    return;
  }

  const txn = w.db.transaction(() => {
    w.insertSession.run(parsed.session);
    for (const msg of parsed.messages) w.insertMessage.run(msg);
    for (const tc of parsed.toolCalls) w.insertToolCall.run(tc);
    for (const [, mu] of parsed.modelUsage) w.insertModelUsage.run(mu);
    for (const sk of extractSkills(parsed)) w.insertSkill.run(sk);

    if (parsed.session.project_path) {
      const name = basename(parsed.session.project_path) || parsed.session.project_path;
      w.insertRepo.run({ path: parsed.session.project_path, name });
      w.updateRepo.run({
        path: parsed.session.project_path,
        last_session_at: parsed.session.started_at,
        total_tokens: parsed.session.total_input_tokens + parsed.session.total_output_tokens,
      });
    }
  });

  txn();
  stats.sessions++;
  stats.messages += parsed.messages.length;
  stats.toolCalls += parsed.toolCalls.length;
}
