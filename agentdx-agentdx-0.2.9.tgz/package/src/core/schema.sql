CREATE TABLE IF NOT EXISTS sessions (
    id                TEXT PRIMARY KEY,
    agent             TEXT NOT NULL,
    agent_version     TEXT,
    title             TEXT,
    status            TEXT DEFAULT 'completed',
    project_path      TEXT,
    repository_url    TEXT,
    git_branch        TEXT,
    git_sha           TEXT,
    model_primary     TEXT,
    started_at        INTEGER NOT NULL,
    ended_at          INTEGER,
    duration_ms       INTEGER,
    total_input_tokens    INTEGER DEFAULT 0,
    total_output_tokens   INTEGER DEFAULT 0,
    total_cache_read      INTEGER DEFAULT 0,
    total_cache_write     INTEGER DEFAULT 0,
    turn_count            INTEGER DEFAULT 0,
    tool_call_count       INTEGER DEFAULT 0,
    first_user_message    TEXT,
    source_path           TEXT,
    collected_at          INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_agent ON sessions(agent);
CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_path);

CREATE TABLE IF NOT EXISTS messages (
    id              TEXT PRIMARY KEY,
    session_id      TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    parent_id       TEXT,
    role            TEXT NOT NULL,
    model           TEXT,
    content_text    TEXT,
    content_type    TEXT DEFAULT 'text',
    timestamp       INTEGER NOT NULL,
    input_tokens    INTEGER DEFAULT 0,
    output_tokens   INTEGER DEFAULT 0,
    cache_read      INTEGER DEFAULT 0,
    cache_write     INTEGER DEFAULT 0,
    seq             INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, seq);

CREATE TABLE IF NOT EXISTS tool_calls (
    id              TEXT PRIMARY KEY,
    session_id      TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    message_id      TEXT,
    tool_name       TEXT NOT NULL,
    tool_input      TEXT,
    tool_output     TEXT,
    is_error        INTEGER DEFAULT 0,
    duration_ms     INTEGER,
    timestamp       INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tool_calls_session ON tool_calls(session_id);
CREATE INDEX IF NOT EXISTS idx_tool_calls_name ON tool_calls(tool_name);

-- Skill / slash-command invocations. One row per invocation.
-- source: 'slash' (user msg `/cmd`), 'command' (<command-name> tag), 'tool' (Skill tool).
CREATE TABLE IF NOT EXISTS skill_invocations (
    id              TEXT PRIMARY KEY,
    session_id      TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    message_id      TEXT,
    skill           TEXT NOT NULL,
    source          TEXT NOT NULL,
    timestamp       INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_skill_inv_session ON skill_invocations(session_id);
CREATE INDEX IF NOT EXISTS idx_skill_inv_skill ON skill_invocations(skill);

CREATE TABLE IF NOT EXISTS model_usage (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    model           TEXT NOT NULL,
    input_tokens    INTEGER DEFAULT 0,
    output_tokens   INTEGER DEFAULT 0,
    cache_read      INTEGER DEFAULT 0,
    cache_write     INTEGER DEFAULT 0,
    message_count   INTEGER DEFAULT 0,
    UNIQUE(session_id, model)
);

CREATE INDEX IF NOT EXISTS idx_model_usage_model ON model_usage(model);

CREATE TABLE IF NOT EXISTS repositories (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    path            TEXT UNIQUE NOT NULL,
    origin_url      TEXT,
    name            TEXT,
    session_count   INTEGER DEFAULT 0,
    last_session_at INTEGER,
    total_tokens    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS collection_state (
    source          TEXT PRIMARY KEY,
    last_file       TEXT,
    last_offset     INTEGER DEFAULT 0,
    last_session_id TEXT,
    last_timestamp  INTEGER,
    updated_at      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS collection_runs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at      INTEGER NOT NULL,
    completed_at    INTEGER,
    source          TEXT NOT NULL,
    sessions_added  INTEGER DEFAULT 0,
    messages_added  INTEGER DEFAULT 0,
    tool_calls_added INTEGER DEFAULT 0,
    errors          TEXT,
    status          TEXT DEFAULT 'running'
);
